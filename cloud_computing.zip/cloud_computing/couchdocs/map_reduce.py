import couchdb


couch = couchdb.Server('http://localhost:15984/')
db1 = couch['twitter_data']
db2 = couch['suburb_data']
# for each in db2:
#     results = db1.view('test/test_view1', key = each)
#     if len(results) != 0:
#         for result in results:
#             print str(each) + ":" + str(result)
#     else:
#         print str(each) + ":" + str(0)
# results = db1.view('test/test_view1', key = "3000")
# for each in results:
#     print each.value
result = []
coordinate = {}
coordinate['coordinate'] = {}
count = 1
for row in db1.view('test_design/test_view'):
    result.append(row.key)
    point_coordinate = row.key
    point = {'long': point_coordinate[0], 'lait': point_coordinate[1]}
    coordinate['coordinate'][count] = point
    count += 1
print coordinate