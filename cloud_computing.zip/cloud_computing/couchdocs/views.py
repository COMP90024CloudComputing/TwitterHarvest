# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render_to_response

from django.http import Http404,HttpResponseRedirect

from couchdb import Server
from couchdb.http import ResourceNotFound
from django.views.decorators.csrf import csrf_exempt
import re
import geojson
from geojson import Feature, Point, FeatureCollection
# Create your views here.

@csrf_exempt
def index(request):
    print "in index"
    return render_to_response('couchdocs/index.html')

@csrf_exempt
def senarios(request):
    print "in senarios"
    url = str(request.get_full_path())
    senarios_num = re.findall(r'.+se+(\d).+',url)
    senarios_num = str(senarios_num[0])
    if senarios_num == '1':
        return render_to_response('couchdocs/se1.html')
    elif senarios_num == '2':
        return render_to_response('couchdocs/se2.html')
    elif senarios_num == '3':
        return render_to_response('couchdocs/se3.html')
    elif senarios_num == '4':
        return render_to_response('couchdocs/se4.html')
    elif senarios_num == '5':
        return render_to_response('couchdocs/se5.html')
    else:
        return render_to_response('couchdocs/se6.html')

@csrf_exempt
def senarios_show(request):
    print "in senarios_show !!!!!"
    url = str(request.get_full_path())
    print url
    senarios_num = re.findall(r'.+se+(\d)_.+',url)
    senarios_num = str(senarios_num[0])
    if senarios_num == '1':
        return render_to_response('couchdocs/heatmap.html')

    elif senarios_num == '2':
        return render_to_response('couchdocs/se2_show.html')
    elif senarios_num == '3':
        return render_to_response('couchdocs/se3_show.html')
    elif senarios_num == '4':
        return render_to_response('couchdocs/se4_show.html')
    elif senarios_num == '5':
        return render_to_response('couchdocs/se5_show.html')
    else:
        return render_to_response('couchdocs/se6_show.html')

def heatmap():

    file = open('static/json/coordinate.geojson','w')
    print 'json file has created'
    couch = Server('http://admin:123@localhost:15984/')
    db1 = couch['twitter_data']
    myfeature_collection = []
    for row in db1.view('test_design/test_view'):
        point_coordinate = row.key
        long = point_coordinate[0]
        lait = point_coordinate[1]
        myfeature_collection.append(Feature(geometry=Point((long, lait))))
    geojson.dump(FeatureCollection(myfeature_collection), file)
    print 'dump success'



